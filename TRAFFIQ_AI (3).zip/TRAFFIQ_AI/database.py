
import sqlite3

DATABASE = "traffic.db"


def get_connection():
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    return connection


def init_db():
    connection = get_connection()

    connection.execute("""
        CREATE TABLE IF NOT EXISTS traffic_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            area TEXT NOT NULL,
            north INTEGER NOT NULL,
            south INTEGER NOT NULL,
            east INTEGER NOT NULL,
            west INTEGER NOT NULL,
            recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    connection.execute("""
        CREATE TABLE IF NOT EXISTS signal_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            area TEXT NOT NULL,
            road TEXT NOT NULL,
            green_time INTEGER NOT NULL,
            decision TEXT NOT NULL,
            officer_id TEXT NOT NULL,
            recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    connection.commit()
    connection.close()


def save_traffic(area, counts):
    connection = get_connection()

    connection.execute("""
        INSERT INTO traffic_data
        (area, north, south, east, west)
        VALUES (?, ?, ?, ?, ?)
    """, (
        area,
        counts["North"],
        counts["South"],
        counts["East"],
        counts["West"]
    ))

    connection.commit()
    connection.close()


def save_decision(area, road, green_time, decision, officer_id):
    connection = get_connection()

    connection.execute("""
        INSERT INTO signal_history
        (area, road, green_time, decision, officer_id)
        VALUES (?, ?, ?, ?, ?)
    """, (area, road, green_time, decision, officer_id))

    connection.commit()
    connection.close()


def get_history():
    connection = get_connection()

    rows = connection.execute("""
        SELECT * FROM signal_history
        ORDER BY id DESC
        LIMIT 20
    """).fetchall()

    connection.close()
    return [dict(row) for row in rows]
