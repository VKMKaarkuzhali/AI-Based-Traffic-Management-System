
const roads = ["North", "South", "East", "West"];

let vehicleCounts = [85, 42, 65, 30];
let proposedRoad = "";
let proposedTime = 0;
let pending = true;
async function loadAIPrediction() {
    const predictionText = document.getElementById("predictionText");

    predictionText.textContent = "Loading AI traffic prediction...";

    try {
        const response = await fetch("/api/predict");

        if (!response.ok) {
            throw new Error("Could not get AI prediction");
        }

        const data = await response.json();

        predictionText.textContent =
            `🤖 AI-Predicted Traffic Volume: ${data.predicted_traffic_volume} vehicles. ` +
            `Model: ${data.model}. ` +
            `Prediction time: ${data.prediction_time}.`;

    } catch (error) {
        console.error("AI prediction error:", error);

        predictionText.textContent =
            "AI prediction is currently unavailable. Please check the server.";
    }
}

function simulateTraffic() {
    vehicleCounts = roads.map(
        () => Math.floor(Math.random() * 100) + 10
    );

    pending = true;

    document.getElementById("approvalStatus").textContent = "";

    updateDashboard();
    saveTrafficToDatabase();
}


function updateDashboard() {
    const total = vehicleCounts.reduce((a, b) => a + b, 0);
    const maxCount = Math.max(...vehicleCounts);
    const maxIndex = vehicleCounts.indexOf(maxCount);

    proposedRoad = roads[maxIndex];

    // Rule-based signal timing for the prototype.
    proposedTime = Math.min(
        90,
        Math.max(20, Math.round(maxCount * 0.65))
    );

    const congestion = maxCount >= 80
        ? "High"
        : maxCount >= 50 ? "Medium" : "Low";

    document.getElementById("totalVehicles").textContent = total;
    document.getElementById("congestionLevel").textContent = congestion;
    document.getElementById("pendingCount").textContent = pending ? 1 : 0;

    document.getElementById("vehicleCounts").innerHTML =
        roads.map((road, i) => `
            <div class="road-item">
                <strong>${road} Road</strong>:
                ${vehicleCounts[i]} vehicles
            </div>
        `).join("");

    document.getElementById("predictionText").textContent =
        `Estimated vehicles in the next interval: ${Math.round(total * 1.1)} (illustrative forecast).`;

    document.getElementById("recommendationText").textContent =
        `Suggested green signal: ${proposedRoad} Road for ${proposedTime} seconds.`;

    document.getElementById("signalSuggestion").textContent =
        `Approve ${proposedTime} seconds green time for ${proposedRoad} Road?`;

    document.getElementById("alertText").textContent =
        congestion === "High"
            ? `⚠ Heavy traffic detected on ${proposedRoad} Road!`
            : "Traffic conditions are manageable.";
}


function approveSignal() {
    if (!pending) return;

    pending = false;

    document.getElementById("approvalStatus").textContent =
        "Signal timing updated in simulation.";

    updateDashboard();
    saveDecisionToDatabase("Approved");
}



function rejectSignal() {
    if (!pending) return;

    pending = false;

    document.getElementById("approvalStatus").textContent =
        "Recommendation rejected. Signal unchanged.";

    updateDashboard();
    saveDecisionToDatabase("Rejected");
}


function addHistory(message) {
    const item = document.createElement("li");
    item.textContent = new Date().toLocaleTimeString() + " - " + message;

    document.getElementById("signalHistory").prepend(item);
}

document.getElementById("trafficArea").addEventListener(
    "change",
    simulateTraffic
);

updateDashboard();

async function saveTrafficToDatabase() {
    const area = document.getElementById("trafficArea").value;

    const counts = {
        North: vehicleCounts[0],
        South: vehicleCounts[1],
        East: vehicleCounts[2],
        West: vehicleCounts[3]
    };

    try {
        const response = await fetch("/api/traffic", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ area, counts })
        });

        if (!response.ok) {
            throw new Error("Failed to save traffic data");
        }

        console.log("Traffic data saved successfully");
    } catch (error) {
        console.error(error);
    }
}

async function saveDecisionToDatabase(decision) {
    const area = document.getElementById("trafficArea").value;

    const data = {
        area: area,
        road: proposedRoad,
        green_time: proposedTime,
        decision: decision
    };

    try {
        const response = await fetch("/api/decision", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        if (!response.ok) {
            throw new Error("Failed to save decision");
        }

        await loadSignalHistory();
    } catch (error) {
        console.error(error);
        document.getElementById("approvalStatus").textContent =
            "Database save failed. Check the server.";
    }
}

async function loadSignalHistory() {
    try {
        const response = await fetch("/api/history");

        if (!response.ok) {
            throw new Error("Failed to load history");
        }

        const history = await response.json();
        const list = document.getElementById("signalHistory");

        list.innerHTML = "";

        history.forEach(item => {
            const li = document.createElement("li");
            li.textContent =
                `${item.recorded_at} - ${item.decision}: ` +
                `${item.road} Road, ${item.green_time}s ` +
                `(${item.area})`;

            list.appendChild(li);
        });
    } catch (error) {
        console.error(error);
    }
}

loadSignalHistory();
loadAIPrediction();

setInterval(loadAIPrediction, 30000);async function updateLiveVehicleCount() {
    try {
        const response = await fetch("/api/live_vehicle_count");

        if (!response.ok) {
            throw new Error("Could not retrieve live vehicle count");
        }

        const data = await response.json();

        document.getElementById("liveVehicleCount").textContent =
            data.vehicle_count;

    } catch (error) {
        console.error("Live vehicle count error:", error);
    }
}

// Update the count every second
setInterval(updateLiveVehicleCount, 1000);

// Get the first count immediately
updateLiveVehicleCount();
async function updateSmartSignalFromCamera() {
    try {
        const response = await fetch("/api/live_vehicle_count");
        const data = await response.json();

        const count = Number(data.vehicle_count ?? data.count ?? 0);

        let greenTime;

        if (count < 5) {
            greenTime = 20;
        } else if (count < 15) {
            greenTime = 40;
        } else {
            greenTime = 60;
        }

        console.log(
            "Live Vehicles:", count,
            "Recommended Green Time:", greenTime, "seconds"
        );
    } catch (error) {
        console.error("Smart signal error:", error);
    }
}

updateSmartSignalFromCamera();
setInterval(updateSmartSignalFromCamera, 3000);