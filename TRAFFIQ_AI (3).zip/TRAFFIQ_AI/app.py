from flask import Response
from vehicle_detection import generate_camera_frames, get_live_vehicle_count
from flask import (
    Flask, render_template, request,
    redirect, url_for, session, jsonify
)

from database import (
    init_db,
    save_traffic,
    save_decision,
    get_history
)
import joblib
import pandas as pd
from datetime import datetime
from pathlib import Path

app = Flask(__name__)
app.secret_key = "traffiq-demo-secret"
# Load trained Random Forest model
BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "model" / "traffic_model.pkl"

traffic_model = joblib.load(MODEL_PATH)

# Officer Login
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        officer_id = request.form.get("officer_id")
        password = request.form.get("password")

        if officer_id == "officer01" and password == "demo123":
            session["officer"] = officer_id
            return redirect(url_for("dashboard"))
        else:
            return render_template(
                "login.html",
                error="Invalid Officer ID or Password"
            )

    return render_template("login.html")


# Dashboard
@app.route("/dashboard")
def dashboard():
    if "officer" not in session:
        return redirect(url_for("login"))

    return render_template("dashboard.html")


# Logout
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# Save Traffic Data
@app.route("/api/traffic", methods=["POST"])
def store_traffic():
    if "officer" not in session:
        return jsonify({"error": "Unauthorized"}), 401

    data = request.get_json(silent=True)

    if not isinstance(data, dict):
        return jsonify({"error": "Invalid data"}), 400

    try:
        area = data["area"]
        counts = data["counts"]

        if not isinstance(area, str) or not area.strip():
            raise ValueError("Invalid area")

        if not isinstance(counts, dict):
            raise ValueError("Invalid counts")

        for road in ["North", "South", "East", "West"]:
            value = counts[road]
            if type(value) is not int or value < 0:
                raise ValueError("Invalid vehicle count")

        save_traffic(area, counts)

    except (KeyError, TypeError, ValueError):
        return jsonify({"error": "Invalid traffic data"}), 400

    return jsonify({"message": "Traffic data saved"})


# Save Officer Approval or Rejection
@app.route("/api/decision", methods=["POST"])
def store_decision():
    if "officer" not in session:
        return jsonify({"error": "Unauthorized"}), 401

    data = request.get_json(silent=True)

    if not isinstance(data, dict):
        return jsonify({"error": "Invalid data"}), 400

    try:
        area = data["area"]
        road = data["road"]
        green_time = data["green_time"]
        decision = data["decision"]

        if not isinstance(area, str) or not area.strip():
            raise ValueError("Invalid area")

        if road not in ["North", "South", "East", "West"]:
            raise ValueError("Invalid road")

        if type(green_time) is not int or not 20 <= green_time <= 90:
            raise ValueError("Invalid green time")

        if decision not in ["Approved", "Rejected"]:
            raise ValueError("Invalid decision")

        save_decision(
            area,
            road,
            green_time,
            decision,
            session["officer"]
        )

    except (KeyError, TypeError, ValueError):
        return jsonify({"error": "Invalid decision data"}), 400

    return jsonify({"message": "Decision saved"})


# Retrieve Signal History
@app.route("/api/history")
def history():
    if "officer" not in session:
        return jsonify({"error": "Unauthorized"}), 401

    return jsonify(get_history())


@app.route("/api/live_vehicle_count")
def api_live_vehicle_count():
    if "officer" not in session:
        return jsonify({"error": "Unauthorized"}), 401

    return jsonify({
        "vehicle_count": get_live_vehicle_count(),
        "source": "YOLO Live Camera"
    })
@app.route("/video_feed")
def video_feed():
    if "officer" not in session:
        return "Unauthorized", 401

    return Response(
        generate_camera_frames(),
        mimetype="multipart/x-mixed-replace; boundary=frame"
    )
# Start Application and Initialize Database
if __name__ == "__main__":
    init_db()
    app.run(debug=True)

# Machine Learning Traffic Prediction API
@app.route("/api/predict", methods=["GET"])
def predict_traffic():
    if "officer" not in session:
        return jsonify({"error": "Unauthorized"}), 401

    now = datetime.now()

    input_data = pd.DataFrame([{
        "hour": now.hour,
        "day_of_week": now.weekday(),
        "month": now.month,
        "is_weekend": int(now.weekday() >= 5)
    }])

    prediction = traffic_model.predict(input_data)[0]

    return jsonify({
        "predicted_traffic_volume": round(float(prediction)),
        "prediction_time": now.strftime("%Y-%m-%d %H:%M:%S"),
        "model": "Random Forest Regression"
    })
