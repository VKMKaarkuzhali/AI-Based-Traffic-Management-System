
from pathlib import Path

import pandas as pd
import joblib

from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

# Step 1: Locate the project and dataset
BASE_DIR = Path(__file__).resolve().parent.parent
DATASET_PATH = BASE_DIR / "dataset" / "Metro_Interstate_Traffic_Volume.csv.gz"

# Step 2: Load dataset
df = pd.read_csv(DATASET_PATH)

print("Dataset loaded successfully!")
print("Total records:", len(df))

# Step 3: Convert date and time
df["date_time"] = pd.to_datetime(df["date_time"])

# Step 4: Create time-based features
df["hour"] = df["date_time"].dt.hour
df["day_of_week"] = df["date_time"].dt.dayofweek
df["month"] = df["date_time"].dt.month
df["is_weekend"] = (df["day_of_week"] >= 5).astype(int)

features = ["hour", "day_of_week", "month", "is_weekend"]

# Step 5: Sort chronologically and remove duplicate timestamps
df = df.sort_values("date_time")
df = df.drop_duplicates(subset=["date_time"], keep="first")
df = df.dropna(subset=features + ["traffic_volume"])

X = df[features]
y = df["traffic_volume"]

# Step 6: Split past and future data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, shuffle=False
)

# Step 7: Train Random Forest
print("Training Random Forest model...")

model = RandomForestRegressor(
    n_estimators=100,
    max_depth=15,
    random_state=42,
    n_jobs=-1
)

model.fit(X_train, y_train)

# Step 8: Evaluate predictions
predictions = model.predict(X_test)

mae = mean_absolute_error(y_test, predictions)
rmse = mean_squared_error(y_test, predictions) ** 0.5
r2 = r2_score(y_test, predictions)

print("\nMODEL EVALUATION")
print("MAE:", round(mae, 2))
print("RMSE:", round(rmse, 2))
print("R2 Score:", round(r2, 4))

# Step 9: Save trained model
MODEL_PATH = BASE_DIR / "model" / "traffic_model.pkl"

joblib.dump(model, MODEL_PATH)

print("\nModel saved successfully!")
print("Location:", MODEL_PATH)
