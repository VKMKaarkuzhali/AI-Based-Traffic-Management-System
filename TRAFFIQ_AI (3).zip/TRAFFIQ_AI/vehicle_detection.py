
import cv2
from ultralytics import YOLO

# Load pretrained YOLO object detection model
model = YOLO("yolo11n.pt")
from threading import Lock

vehicle_count_lock = Lock()
live_vehicle_count = 0


def get_live_vehicle_count():
    with vehicle_count_lock:
        return live_vehicle_count






def generate_camera_frames():
    global live_vehicle_count

    camera = cv2.VideoCapture(0)

    if not camera.isOpened():
        print("Unable to open camera")
        return

    try:
        while True:
            success, frame = camera.read()

            if not success:
                break

            results = model(frame, verbose=False)[0]
            vehicle_count = 0

            for box in results.boxes:
                class_id = int(box.cls[0])
                class_name = model.names[class_id]

                if class_name in ["car", "motorcycle", "bus", "truck"]:
                    vehicle_count += 1

                    x1, y1, x2, y2 = map(int, box.xyxy[0])

                    cv2.rectangle(
                        frame, (x1, y1), (x2, y2), (0, 255, 0), 2
                    )

                    cv2.putText(
                        frame, class_name,
                        (x1, max(y1 - 10, 20)),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.6, (0, 255, 0), 2
                    )

            with vehicle_count_lock:
                live_vehicle_count = vehicle_count

            cv2.putText(
                frame, f"Vehicles: {vehicle_count}",
                (20, 40),
                cv2.FONT_HERSHEY_SIMPLEX,
                1, (0, 255, 255), 2
            )

            success, buffer = cv2.imencode(".jpg", frame)

            if success:
                yield (
                    b"--frame\r\n"
                    b"Content-Type: image/jpeg\r\n\r\n"
                    + buffer.tobytes()
                    + b"\r\n"
                )

    finally:
        camera.release()