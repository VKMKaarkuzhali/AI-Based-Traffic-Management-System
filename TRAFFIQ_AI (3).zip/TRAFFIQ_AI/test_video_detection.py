
import cv2
from ultralytics import YOLO

# Load YOLO model
model = YOLO("yolo11n.pt")

# Open downloaded traffic video
video = cv2.VideoCapture("videos/27289-363287627.mp4")
video.set(cv2.CAP_PROP_POS_FRAMES, 0)
print("Video FPS:", video.get(cv2.CAP_PROP_FPS))

if not video.isOpened():
    print("Cannot open traffic video!")
    exit()

print("YOLO vehicle detection started!")

while True:
    success, frame = video.read()

    if not success:
        break

    results = model(frame, verbose=False)[0]
    vehicle_count = 0

    for box in results.boxes:
        class_id = int(box.cls[0])
        class_name = model.names[class_id]

        if class_name in ["car", "motorcycle", "bus", "truck"]:
            vehicle_count += 1

            x1, y1, x2, y2 = map(int, box.xyxy[0])

            cv2.rectangle(
                frame, (x1, y1), (x2, y2),
                (0, 255, 0), 2
            )

            cv2.putText(
                frame, class_name,
                (x1, max(y1 - 10, 20)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6, (0, 255, 0), 2
            )

    cv2.putText(
        frame,
        f"Vehicles Detected: {vehicle_count}",
        (20, 40),
        cv2.FONT_HERSHEY_SIMPLEX,
        1, (0, 255, 255), 2
    )

    cv2.imshow("TRAFFIQ AI - Traffic Detection", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

video.release()
cv2.destroyAllWindows()

print("Video detection completed!")
